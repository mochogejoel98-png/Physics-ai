package com.lynx.physicsai;

import java.util.Locale;

public final class UnitCalculator {
    private UnitCalculator() {}

    public static double divide(double numerator, double denominator) {
        if (denominator == 0.0) {
            throw new IllegalArgumentException("Cannot divide by zero.");
        }
        return numerator / denominator;
    }

    public static double multiply(double first, double second) {
        return first * second;
    }

    public static String format(double value) {
        if (Math.abs(value - Math.rint(value)) < 1e-9) {
            return String.format(Locale.US, "%.0f", value);
        }
        return String.format(Locale.US, "%.4f", value).replaceAll("0+$", "").replaceAll("\\\\.$", "");
    }
}
