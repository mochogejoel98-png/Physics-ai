package com.lynx.physicsai

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ArrayAdapter
import android.widget.Spinner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val smartAnswerEngine = SmartAnswerEngine()
    private lateinit var discovery: KnowledgeDiscovery
    private lateinit var savedKnowledgeStore: SavedKnowledgeStore
    private lateinit var aiSettingsStore: AiSettingsStore
    private val languageModelClient = LanguageModelClient()
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastResearchResult: KnowledgeDiscovery.ResearchResult? = null
    private var lastResearchQuestion: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        discovery = KnowledgeDiscovery(this)
        savedKnowledgeStore = SavedKnowledgeStore(this)
        aiSettingsStore = AiSettingsStore(this)

        val questionInput = findViewById<EditText>(R.id.questionInput)
        val solveButton = findViewById<Button>(R.id.solveButton)
        val onlineButton = findViewById<Button>(R.id.onlineSearchButton)
        val saveButton = findViewById<Button>(R.id.saveResearchButton)
        val libraryButton = findViewById<Button>(R.id.openLibraryButton)
        val aiButton = findViewById<Button>(R.id.aiAnswerButton)
        val aiSettingsButton = findViewById<Button>(R.id.aiSettingsButton)
        val aiTestButton = findViewById<Button>(R.id.aiTestButton)
        val answerOutput = findViewById<TextView>(R.id.answerOutput)
        val statusText = findViewById<TextView>(R.id.statusText)

        solveButton.setOnClickListener {
            val question = questionInput.text.toString().trim()
            if (question.isBlank()) {
                answerOutput.text = "Please type a question first."
                return@setOnClickListener
            }
            val result = smartAnswerEngine.answer(question)
            answerOutput.text = result.text
            if (result.needsOnlineResearch) {
                runOnlineSearch(question, answerOutput, statusText, solveButton, onlineButton)
            } else {
                statusText.text = result.status
            }
        }

        onlineButton.setOnClickListener {
            val question = questionInput.text.toString().trim()
            if (question.isBlank()) {
                answerOutput.text = "Type a question or topic to search online."
                return@setOnClickListener
            }
            runOnlineSearch(question, answerOutput, statusText, solveButton, onlineButton)
        }


        aiSettingsButton.setOnClickListener {
            showAiSettingsDialog(statusText)
        }

        aiTestButton.setOnClickListener {
            val settings = aiSettingsStore.load()
            if (settings.apiKey.isBlank()) {
                statusText.text = "API key missing. Open AI Provider Settings first."
                showAiSettingsDialog(statusText)
                return@setOnClickListener
            }
            aiTestButton.isEnabled = false
            aiButton.isEnabled = false
            statusText.text = "Testing the selected provider and model…"
            answerOutput.text = "Sending a small test request. Please wait."
            worker.execute {
                try {
                    val reply = languageModelClient.answer(
                        "Reply with exactly this sentence and nothing else: PhysicsAI connection test successful.",
                        LanguageModelClient.Config(settings.baseUrl, settings.model, settings.apiKey)
                    )
                    mainHandler.post {
                        answerOutput.text = "CONNECTION TEST PASSED\n\n${reply.text}\n\nProvider/model returned: ${reply.model}\n\nThis confirms the API answered; it does not verify physics accuracy."
                        statusText.text = "API connection successful."
                        aiTestButton.isEnabled = true
                        aiButton.isEnabled = true
                    }
                } catch (error: Exception) {
                    mainHandler.post {
                        answerOutput.text = "CONNECTION TEST FAILED\n\n${error.message ?: error.javaClass.simpleName}\n\nCheck the selected provider, exact model ID, API key, account quota, and internet connection."
                        statusText.text = "API connection failed. See the diagnostic message below."
                        aiTestButton.isEnabled = true
                        aiButton.isEnabled = true
                    }
                }
            }
        }

        aiButton.setOnClickListener {
            val question = questionInput.text.toString().trim()
            if (question.isBlank()) {
                answerOutput.text = "Type a question for the AI first."
                return@setOnClickListener
            }
            val settings = aiSettingsStore.load()
            if (settings.apiKey.isBlank()) {
                statusText.text = "AI API key is not configured."
                showAiSettingsDialog(statusText)
                return@setOnClickListener
            }
            solveButton.isEnabled = false
            onlineButton.isEnabled = false
            aiButton.isEnabled = false
            statusText.text = "Asking the language model…"
            answerOutput.text = "Preparing a step-by-step answer. Please wait."
            worker.execute {
                try {
                    val reply = languageModelClient.answer(
                        question,
                        LanguageModelClient.Config(settings.baseUrl, settings.model, settings.apiKey)
                    )
                    mainHandler.post {
                        answerOutput.text = buildString {
                            appendLine("AI-ASSISTED EXPLANATION")
                            appendLine()
                            appendLine(reply.text)
                            appendLine()
                            appendLine("Model reported by provider: ${reply.model}")
                            append("Verification note: this answer was generated by an AI model and was not independently proven. Check formulas, units, and important facts.")
                        }
                        statusText.text = "AI response received. Review it before relying on it."
                        solveButton.isEnabled = true
                        onlineButton.isEnabled = true
                        aiButton.isEnabled = true
                    }
                } catch (error: Exception) {
                    mainHandler.post {
                        answerOutput.text = "AI REQUEST FAILED\n\n${error.message ?: "Unexpected error."}\n\nYou can still use offline explanations and online article search. Check your API key, model, internet connection, and provider access."
                        statusText.text = "AI request failed."
                        solveButton.isEnabled = true
                        onlineButton.isEnabled = true
                        aiButton.isEnabled = true
                    }
                }
            }
        }

        saveButton.setOnClickListener {
            val result = lastResearchResult
            val question = lastResearchQuestion
            if (result == null || question.isBlank()) {
                statusText.text = "Search online first, then save a useful result."
                return@setOnClickListener
            }
            try {
                val entry = savedKnowledgeStore.save(question, result.title, result.summary, result.sourceUrl)
                statusText.text = "Saved locally as 'Needs review'. Review the source before relying on it."
                answerOutput.append("\n\nSaved to My Knowledge • ${entry.formattedDate()}")
            } catch (error: Exception) {
                statusText.text = "Could not save result: ${error.message ?: "unknown error"}"
            }
        }

        libraryButton.setOnClickListener {
            showSavedKnowledgeDialog(statusText, answerOutput)
        }
    }

    private fun runOnlineSearch(
        question: String,
        output: TextView,
        status: TextView,
        solveButton: Button,
        onlineButton: Button
    ) {
        solveButton.isEnabled = false
        onlineButton.isEnabled = false
        status.text = "Searching online…"
        output.text = "Looking for a relevant article and checking its summary.\n\nPlease wait."

        worker.execute {
            try {
                val result = discovery.search(question)
                val answer = smartAnswerEngine.reviewOnlineResult(question, result)
                mainHandler.post {
                    lastResearchResult = result
                    lastResearchQuestion = question
                    output.text = answer
                    status.text = if (result.fromCache) {
                        "Loaded saved online research. It may be out of date."
                    } else {
                        "Online search complete. Review the source before saving."
                    }
                    solveButton.isEnabled = true
                    onlineButton.isEnabled = true
                }
            } catch (error: Exception) {
                mainHandler.post {
                    output.text = "ONLINE SEARCH COULD NOT COMPLETE\n\n${error.message ?: "An unexpected error occurred."}\n\nYou can still ask about topics in the offline physics library. Check your connection and try again."
                    status.text = "Online search unavailable."
                    solveButton.isEnabled = true
                    onlineButton.isEnabled = true
                }
            }
        }
    }


    private data class ProviderPreset(val name: String, val baseUrl: String, val model: String)

    private fun showAiSettingsDialog(statusText: TextView) {
        val current = aiSettingsStore.load()
        val presets = listOf(
            ProviderPreset("OpenAI", "https://api.openai.com/v1", "gpt-4.1-mini"),
            ProviderPreset("Google Gemini (OpenAI-compatible API)", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-3.8-flash"),
            ProviderPreset("DeepSeek", "https://api.deepseek.com", "deepseek-chat"),
            ProviderPreset("Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
            ProviderPreset("OpenRouter (many model providers)", "https://openrouter.ai/api/v1", "openai/gpt-4.1-mini"),
            ProviderPreset("Mistral AI", "https://api.mistral.ai/v1", "mistral-small-latest"),
            ProviderPreset("xAI Grok", "https://api.x.ai/v1", "grok-3-mini"),
            ProviderPreset("Together AI", "https://api.together.ai/v1", "meta-llama/Llama-3.3-70B-Instruct-Turbo"),
            ProviderPreset("Fireworks AI", "https://api.fireworks.ai/inference/v1", "accounts/fireworks/models/llama-v3p3-70b-instruct"),
            ProviderPreset("Cerebras", "https://api.cerebras.ai/v1", "llama-3.3-70b"),
            ProviderPreset("Perplexity", "https://api.perplexity.ai", "sonar"),
            ProviderPreset("Custom OpenAI-compatible API", current.baseUrl, current.model)
        )
        val fields = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 12, 32, 0)
        }
        val providerPicker = Spinner(this)
        providerPicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            presets.map { it.name })
        val urlInput = EditText(this).apply {
            hint = "API base URL"; setSingleLine(true); setText(current.baseUrl)
        }
        val modelInput = EditText(this).apply {
            hint = "Model ID from provider"; setSingleLine(true); setText(current.model)
        }
        val keyInput = EditText(this).apply {
            hint = "API key (keep private)"; setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(current.apiKey)
        }
        val matchingPreset = presets.indexOfFirst { it.baseUrl.trimEnd('/') == current.baseUrl.trimEnd('/') }
        providerPicker.setSelection(if (matchingPreset >= 0) matchingPreset else presets.lastIndex)
        providerPicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val selected = presets[position]
                if (selected.name != "Custom OpenAI-compatible API") {
                    urlInput.setText(selected.baseUrl)
                    modelInput.setText(selected.model)
                }
            }
        }
        fields.addView(providerPicker)
        fields.addView(urlInput)
        fields.addView(modelInput)
        fields.addView(keyInput)

        AlertDialog.Builder(this)
            .setTitle("Choose an AI API provider")
            .setMessage("Choose a preset or Custom. Presets are starting points: model IDs and access vary by account and may change. This version supports OpenAI-compatible Chat Completions APIs; providers with a different native API format may need an adapter. API use may cost money. Keep keys private.")
            .setView(fields)
            .setPositiveButton("Save") { _, _ ->
                try {
                    aiSettingsStore.save(urlInput.text.toString(), modelInput.text.toString(), keyInput.text.toString())
                    statusText.text = "Provider saved: ${providerPicker.selectedItem}. You can change it anytime."
                } catch (error: Exception) {
                    statusText.text = "Settings not saved: ${error.message ?: "check the values"}"
                }
            }
            .setNeutralButton("Clear key") { _, _ ->
                aiSettingsStore.clearKey()
                statusText.text = "Stored API key cleared."
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSavedKnowledgeDialog(statusText: TextView, answerOutput: TextView) {
        val entries = savedKnowledgeStore.all()
        if (entries.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("My Saved Knowledge")
                .setMessage("Your library is empty. Search online and tap 'Save online result' to add an entry.")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        val labels = entries.map { entry ->
            val review = if (entry.reviewed) "Reviewed by you" else "Needs review"
            "$review • ${entry.title}\n${entry.formattedDate()}"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("My Saved Knowledge (${entries.size})")
            .setItems(labels) { _, index ->
                val entry = entries[index]
                val details = buildString {
                    appendLine(entry.title)
                    appendLine()
                    appendLine("Question: ${entry.question}")
                    appendLine("Saved: ${entry.formattedDate()}")
                    appendLine("Status: ${if (entry.reviewed) "Reviewed by you" else "Needs review"}")
                    appendLine()
                    appendLine(entry.summary)
                    appendLine()
                    append("Source: ${entry.sourceUrl}")
                }
                val reviewLabel = if (entry.reviewed) "Already reviewed" else "Mark reviewed"
                AlertDialog.Builder(this)
                    .setTitle(entry.title)
                    .setMessage(details)
                    .setPositiveButton(reviewLabel) { _, _ ->
                        if (!entry.reviewed) {
                            savedKnowledgeStore.markReviewed(entry.id)
                            statusText.text = "Marked reviewed by you. This is not proof that the claims are true."
                        } else {
                            statusText.text = "This entry is already marked reviewed."
                        }
                    }
                    .setNeutralButton("Delete entry") { _, _ ->
                        savedKnowledgeStore.delete(entry.id)
                        statusText.text = "Saved entry deleted."
                    }
                    .setNegativeButton("Open source") { _, _ ->
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(entry.sourceUrl)))
                        } catch (_: Exception) {
                            statusText.text = "Could not open the source link on this device."
                        }
                    }
                    .show()
            }
            .setNegativeButton("Clear all") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Delete all saved knowledge?")
                    .setMessage("This permanently removes every saved research entry from this app on this device.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete all") { _, _ ->
                        val count = savedKnowledgeStore.clear()
                        statusText.text = "Deleted $count saved entries."
                        answerOutput.text = "Your saved knowledge library is now empty."
                    }
                    .show()
            }
            .setPositiveButton("Close", null)
            .show()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }
}
