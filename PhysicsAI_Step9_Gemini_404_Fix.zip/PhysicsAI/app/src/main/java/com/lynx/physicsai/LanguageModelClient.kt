package com.lynx.physicsai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Optional OpenAI-compatible Chat Completions client.
 *
 * The API key is supplied by the user at runtime and kept in app-private
 * SharedPreferences. For a public production app, move provider calls to a
 * backend so a key is never distributed inside the APK.
 */
class LanguageModelClient {
    data class Config(
        val baseUrl: String,
        val model: String,
        val apiKey: String
    )

    data class ModelReply(
        val text: String,
        val model: String
    )

    fun answer(question: String, config: Config): ModelReply {
        require(question.isNotBlank()) { "Please enter a question." }
        require(config.apiKey.isNotBlank()) { "API key is missing. Open AI Provider Settings and enter the key for the selected provider." }
        require(config.model.isNotBlank()) { "Model ID is empty. Copy an available model ID from your provider dashboard." }
        val base = config.baseUrl.trim().trimEnd('/')
        require(base.startsWith("https://", ignoreCase = true)) {
            "API URL must start with https://. Check the provider URL in AI Provider Settings."
        }
        val endpoint = when {
            base.endsWith("/chat/completions", ignoreCase = true) -> base
            else -> "$base/chat/completions"
        }
        val url = try { URL(endpoint) } catch (e: Exception) {
            throw IllegalStateException("Invalid API URL: $endpoint", e)
        }
        val requestBody = JSONObject().apply {
            put("model", config.model.trim())
            put("temperature", 0.15)
            put("max_tokens", 1800)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
                put(JSONObject().put("role", "user").put("content", question.trim()))
            })
        }.toString()

        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            useCaches = false
            instanceFollowRedirects = true
            setRequestProperty("Authorization", "Bearer ${config.apiKey.trim()}")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }

        try {
            connection.outputStream.use { stream ->
                stream.write(requestBody.toByteArray(StandardCharsets.UTF_8))
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val providerMessage = extractErrorMessage(body)
                val diagnosis = when (code) {
                    400 -> "The request or model ID may not be supported. Verify the exact model ID and provider API format."
                    401 -> "The API key is invalid, expired, or belongs to a different provider."
                    403 -> "This key/account may not have permission to use this model."
                    404 -> "The endpoint or model was not found. Check the base URL and model ID."
                    408 -> "The provider timed out. Try again."
                    429 -> "Rate limit or account quota reached. Check provider usage, billing, and limits."
                    in 500..599 -> "The provider server is having a problem. Try again later."
                    else -> "Check the provider URL, key, model ID, and API compatibility."
                }
                throw IllegalStateException(
                    "AI API error (HTTP $code). $diagnosis" +
                        (providerMessage?.takeIf { it.isNotBlank() }?.let { "\nProvider detail: $it" } ?: "")
                )
            }

            val json = try { JSONObject(body) } catch (e: Exception) {
                throw IllegalStateException("The provider returned HTTP $code but not valid JSON. Check that the URL points to a Chat Completions API endpoint.", e)
            }
            val choices = json.optJSONArray("choices")
            if (choices == null) {
                val outputText = json.optString("output_text", "").trim()
                if (outputText.isNotBlank()) return ModelReply(outputText, json.optString("model", config.model))
                val providerMessage = extractErrorMessage(body)
                throw IllegalStateException(
                    "The provider response has no 'choices' field. This app expects an OpenAI-compatible /chat/completions endpoint." +
                        (providerMessage?.let { " Provider detail: $it" } ?: "")
                )
            }
            if (choices.length() == 0) throw IllegalStateException("The AI provider returned no answer.")
            val choice = choices.getJSONObject(0)
            val message = choice.optJSONObject("message")
            val content = message?.opt("content")
            val text = when (content) {
                is String -> content.trim()
                is JSONArray -> buildString {
                    for (i in 0 until content.length()) {
                        val part = content.optJSONObject(i) ?: continue
                        val partText = (part.optString("text", "").takeIf { it.isNotBlank() }
                            ?: part.optString("content", "")).trim()
                        if (partText.isNotBlank()) {
                            if (isNotEmpty()) append("\n")
                            append(partText)
                        }
                    }
                }.trim()
                else -> ""
            }
            if (text.isBlank()) {
                val finishReason = choice.optString("finish_reason", "unknown")
                throw IllegalStateException("The provider returned no readable answer (finish reason: $finishReason). Try a different model or check its API compatibility.")
            }
            val finishReason = choice.optString("finish_reason", "")
            val finalText = if (finishReason == "length" || finishReason == "max_tokens") {
                text + "\n\n[This answer may be incomplete because the model reached its output limit.]"
            } else text
            return ModelReply(finalText, json.optString("model", config.model))
        } finally {
            connection.disconnect()
        }
    }

    private fun extractErrorMessage(body: String): String? = try {
        val json = JSONObject(body)
        val error = json.opt("error")
        when (error) {
            is JSONObject -> error.optString("message", "").takeIf { it.isNotBlank() }
                ?: error.optString("detail", "").takeIf { it.isNotBlank() }
            is String -> error.takeIf { it.isNotBlank() }
            else -> json.optString("message", "").takeIf { it.isNotBlank() }
                ?: json.optString("detail", "").takeIf { it.isNotBlank() }
        }
    } catch (_: Exception) { null }

    companion object {
        private const val SYSTEM_PROMPT = """
You are PhysicsAI, a careful, patient physics tutor and scientific reasoning assistant. Your job is to help a learner understand, not merely produce an answer. Use clear, age-appropriate language and organize the response so it is easy to study.

FIRST, understand the request. It may be a numerical problem, a concept/definition, a derivation, an experiment, a comparison, a real-world question, or a question outside physics. Answer the actual question and do not force every question into a calculation.

FOR NUMERICAL PHYSICS PROBLEMS, use these headings when relevant:
1. What is being asked
2. Given information (include units)
3. Find
4. Physics idea and why it applies
5. Formula (define every symbol)
6. Rearrangement, if needed
7. Substitution with values and units
8. Calculation, one step at a time
9. Final answer with correct SI unit and sensible significant figures
10. Check: dimensions/units, direction or sign if relevant, and whether the result is physically reasonable

Do not skip intermediate steps. Keep calculations internally consistent. Convert units before substituting when needed. Do not invent missing values. If a value is missing, give a symbolic answer if useful and clearly state what extra information is needed. If more than one interpretation is possible, state the most likely assumption and briefly mention alternatives.

FOR CONCEPTUAL QUESTIONS: start with a direct definition or answer, explain how/why it works, give a simple example or analogy, and list important conditions or limitations. For compare/contrast questions, use paired points or a small table if helpful. For derivations, show the logical steps and explain the assumptions.

SCIENTIFIC QUALITY: distinguish established scientific knowledge from simplified models, estimates, hypotheses, and open questions. Be explicit about uncertainty. Never fabricate formulas, numerical constants, citations, experiments, or claims that you searched the web. If you are unsure, say what you are unsure about and offer the best-supported explanation. Do not present a calculation as independently verified unless you actually performed the check in your answer.

STYLE: use descriptive headings, numbered steps, readable equations, and concise explanations. Avoid vague one-line answers when the user needs an explanation, but do not pad simple questions with irrelevant material. If the learner asks for only the answer, be concise. If the user asks for points, use bullet points. End with a clear conclusion. You may answer general questions too, while being honest when they are outside physics.
"""
    }
}
