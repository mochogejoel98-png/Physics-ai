package com.lynx.physicsai

import java.util.Locale
import kotlin.math.abs

/**
 * Step 3 reasoning layer.
 *
 * This is a transparent rule-based checker, not a machine-learning model.
 * It checks supported arithmetic, flags unit limitations, and explains
 * what kind of verification was actually performed.
 */
class SmartAnswerEngine {
    data class AnswerResult(
        val text: String,
        val status: String,
        val needsOnlineResearch: Boolean = false
    )

    private val explanationEngine = ExplanationEngine()
    private val physicsEngine = PhysicsEngine()

    fun answer(question: String): AnswerResult {
        val cleaned = question.trim()
        if (cleaned.isBlank()) {
            return AnswerResult("Please type a question first.", "Waiting for a question.")
        }

        val local = physicsEngine.answer(cleaned)
        if (local.contains("couldn't confidently match", ignoreCase = true)) {
            val explanation = explanationEngine.explain(cleaned)
            return AnswerResult(
                explanation + "\n\nSTEP 3: SMART ROUTING\n" +
                    "1. I checked the offline knowledge library.\n" +
                    "2. I did not find a confident match.\n" +
                    "3. The next step is to search online and show the source rather than invent an answer.",
                "Offline match not found; online research is needed.",
                needsOnlineResearch = true
            )
        }

        val explained = explanationEngine.explain(cleaned)
        val mathCheck = verifySupportedCalculation(local)
        val answerText = buildString {
            append(explained)
            appendLine()
            appendLine()
            appendLine("STEP 3: SMART VERIFICATION")
            appendLine("1. Question handling: matched the question to the local physics knowledge rules.")
            if (mathCheck != null) {
                appendLine("2. Arithmetic check: $mathCheck")
            } else {
                appendLine("2. Calculation check: no independent numeric recalculation was available for this type of answer.")
            }
            appendLine("3. Scope check: the app's current automatic numerical solvers support speed and density examples; other topics may provide definitions and formulas only.")
            append("4. Confidence note: this is a rule-based consistency check, not independent scientific proof. Check a textbook, teacher, or reliable reference for important work.")
        }

        val status = if (mathCheck?.startsWith("PASS") == true) {
            "Offline answer ready • arithmetic check passed."
        } else {
            "Offline answer ready • review the verification note."
        }
        return AnswerResult(answerText, status)
    }

    /**
     * Recalculates the supported divide-based examples from the values printed
     * by PhysicsEngine. It does not claim to verify unsupported calculations.
     */
    private fun verifySupportedCalculation(localAnswer: String): String? {
        if (!localAnswer.startsWith("SOLUTION:")) return null

        val substitutionLine = localAnswer.lineSequence()
            .firstOrNull { it.startsWith("Substitute:") } ?: return "REVIEW: substitution values were not found."
        val answerLine = localAnswer.lineSequence()
            .firstOrNull { it.startsWith("Answer:") } ?: return "REVIEW: final numeric answer was not found."

        val division = Regex("""(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)""")
            .find(substitutionLine) ?: return "REVIEW: could not parse the division in the substitution."
        val printedResult = Regex("""=\s*(-?\d+(?:\.\d+)?)""")
            .find(answerLine)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            ?: return "REVIEW: could not parse the final numeric answer."

        val numerator = division.groupValues[1].toDoubleOrNull()
            ?: return "REVIEW: numerator could not be read."
        val denominator = division.groupValues[2].toDoubleOrNull()
            ?: return "REVIEW: denominator could not be read."
        if (denominator == 0.0) return "PASS: division-by-zero protection is active; no valid result should be produced."

        val recomputed = numerator / denominator
        val tolerance = maxOf(1e-6, abs(recomputed) * 1e-4)
        return if (abs(recomputed - printedResult) <= tolerance) {
            "PASS: recomputed $numerator ÷ $denominator = ${UnitCalculator.format(recomputed)}, matching the displayed result."
        } else {
            "WARNING: recomputation gives ${UnitCalculator.format(recomputed)}, but the displayed result is ${UnitCalculator.format(printedResult)}. Review the answer."
        }
    }

    fun reviewOnlineResult(question: String, result: KnowledgeDiscovery.ResearchResult): String {
        val queryWords = question.lowercase(Locale.ROOT)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length > 2 }
            .toSet()
        val articleWords = (result.title + " " + result.summary).lowercase(Locale.ROOT)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length > 2 }
            .toSet()
        val overlap = queryWords.intersect(articleWords).size
        val plausibleMatch = overlap > 0

        return buildString {
            appendLine("ONLINE KNOWLEDGE DISCOVERY")
            appendLine()
            appendLine("1. Question searched: $question")
            appendLine("2. Matching article: ${result.title}")
            appendLine("3. Source summary:")
            appendLine(result.summary)
            appendLine()
            appendLine("4. Source link: ${result.sourceUrl}")
            appendLine()
            appendLine("STEP 3: SOURCE AND RELEVANCE CHECK")
            appendLine(if (result.sourceUrl.startsWith("https://")) {
                "5. Link check: the source uses HTTPS."
            } else {
                "5. Link check: the source URL could not be confirmed as HTTPS. Open it cautiously."
            })
            appendLine(if (plausibleMatch) {
                "6. Relevance check: some words from your question appear in the article title or summary. This is a basic text match, not proof that the article fully answers the question."
            } else {
                "6. Relevance warning: I could not find a clear word overlap between the question and this article. The result may be unrelated; try a more specific search."
            })
            appendLine("7. Evidence level: one Wikipedia article summary. I have not independently confirmed the claims with a second source.")
            appendLine("8. Recommended next step: compare important claims with a physics textbook, university material, or another reputable source.")
            appendLine()
            append(if (result.fromCache) {
                "Cache note: this result was loaded from the device's saved research. It may be out of date."
            } else {
                "Cache note: this result has been saved on this device for future reuse. Saved information may become out of date."
            })
        }
    }
}
