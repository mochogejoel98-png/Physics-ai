package com.lynx.physicsai

/** Turns the current offline knowledge engine's results into a learner-friendly sequence. */
class ExplanationEngine {
    private val physicsEngine = PhysicsEngine()

    fun explain(question: String): String {
        val q = question.trim()
        if (q.isBlank()) return "Please type a question first."

        val base = physicsEngine.answer(q)
        if (base.contains("couldn't confidently match", ignoreCase = true)) {
            return "NEEDS ONLINE RESEARCH\n\nI couldn't find a confident match in my saved physics knowledge. I'll search online for a useful starting point.\n\nQuestion: $q"
        }

        if (base.startsWith("SOLUTION:")) {
            val lines = base.lines().filter { it.isNotBlank() }
            val formula = lines.firstOrNull { it.startsWith("Formula:") }?.removePrefix("Formula:")?.trim()
            val substitute = lines.firstOrNull { it.startsWith("Substitute:") }?.removePrefix("Substitute:")?.trim()
            val answer = lines.firstOrNull { it.startsWith("Answer:") }?.removePrefix("Answer:")?.trim()
            val definition = lines.firstOrNull { it.startsWith("Definition:") }?.removePrefix("Definition:")?.trim()
            val check = lines.firstOrNull { it.startsWith("Check:") }?.removePrefix("Check:")?.trim()
            return buildString {
                appendLine("POINT-BY-POINT EXPLANATION")
                appendLine("1. Understand the question: We need to calculate a physics quantity from the values provided.")
                appendLine("2. Identify the idea: ${definition ?: "Use the relationship described by the formula."}")
                if (formula != null) appendLine("3. Choose the formula: $formula")
                if (substitute != null) appendLine("4. Put the given values into the formula: $substitute")
                appendLine("5. Calculate: ${answer ?: "Follow the substitution carefully."}")
                if (check != null) appendLine("6. Check the result: $check")
                appendLine("7. Interpret the answer: Make sure the numerical value and units match what the question asks for.")
                appendLine()
                appendLine("FULL RESULT")
                append(base)
            }
        }

        if (base.startsWith("TOPIC:") || base.startsWith("ADVANCED PHYSICS KNOWLEDGE")) {
            return "POINT-BY-POINT EXPLANATION\n\n1. Identify the topic: This question matches information in my saved physics library.\n2. Learn the meaning: Read the definition or topic summary below.\n3. Understand the formula: Check what each symbol represents and the units used.\n4. Check the limits: A formula is only reliable when its stated conditions are met.\n5. Ask a follow-up: You can ask for an example, a simpler definition, or a calculation.\n\n$base"
        }
        return base
    }
}
