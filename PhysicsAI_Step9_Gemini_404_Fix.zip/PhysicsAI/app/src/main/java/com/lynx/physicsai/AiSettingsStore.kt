package com.lynx.physicsai

import android.content.Context

/**
 * Stores optional provider configuration in app-private preferences.
 * This is suitable for personal testing only, not for distributing an APK with
 * a shared API key. A backend is recommended for a public app.
 */
class AiSettingsStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("physicsai_ai_settings", Context.MODE_PRIVATE)

    data class Settings(
        val baseUrl: String,
        val model: String,
        val apiKey: String
    )

    fun load(): Settings = Settings(
        baseUrl = prefs.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL,
        model = prefs.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL,
        apiKey = prefs.getString(KEY_API_KEY, "") ?: ""
    )

    fun save(baseUrl: String, model: String, apiKey: String) {
        val normalizedUrl = baseUrl.trim()
        require(normalizedUrl.startsWith("https://")) {
            "Use a secure HTTPS API base URL. Local HTTP inference servers are not enabled in this build."
        }
        require(model.trim().isNotBlank()) { "Model name cannot be empty." }
        prefs.edit()
            .putString(KEY_BASE_URL, normalizedUrl.trimEnd('/'))
            .putString(KEY_MODEL, model.trim())
            .putString(KEY_API_KEY, apiKey.trim())
            .apply()
    }

    fun clearKey() {
        prefs.edit().remove(KEY_API_KEY).apply()
    }

    companion object {
        private const val KEY_BASE_URL = "base_url"
        private const val KEY_MODEL = "model"
        private const val KEY_API_KEY = "api_key"
        const val DEFAULT_BASE_URL = "https://api.openai.com/v1"
        const val DEFAULT_MODEL = "gpt-4.1-mini"
    }
}
