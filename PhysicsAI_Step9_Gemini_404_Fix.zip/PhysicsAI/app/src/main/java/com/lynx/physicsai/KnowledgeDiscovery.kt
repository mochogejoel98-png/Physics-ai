package com.lynx.physicsai

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.nio.charset.StandardCharsets

/** Public Wikipedia API lookup. Network calls must be made off the Android main thread. */
class KnowledgeDiscovery(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences("physicsai_research_cache", Context.MODE_PRIVATE)

    data class ResearchResult(
        val title: String,
        val summary: String,
        val sourceUrl: String,
        val fromCache: Boolean = false
    )

    fun search(query: String): ResearchResult {
        val cleaned = query.trim()
        require(cleaned.isNotEmpty()) { "Please enter a question." }

        val cacheKey = cleaned.lowercase().replace(Regex("\\s+"), " ")
        val cached = preferences.getString(cacheKey, null)
        if (cached != null) {
            val obj = JSONObject(cached)
            return ResearchResult(obj.optString("title"), obj.optString("summary"), obj.optString("url"), true)
        }

        val encoded = URLEncoder.encode(cleaned, StandardCharsets.UTF_8.name())
        val searchUrl = URL("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encoded&format=json&utf8=1&srlimit=5")
        val searchJson = JSONObject(readUrl(searchUrl))
        val results = searchJson.optJSONObject("query")?.optJSONArray("search")
        if (results == null || results.length() == 0) {
            throw IllegalStateException("No useful Wikipedia result was found. Try rephrasing the question or use a more specific topic.")
        }

        // Prefer a title match; otherwise use the top search result.
        val queryWords = cleaned.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length > 2 }.toSet()
        var chosen = results.getJSONObject(0)
        for (i in 0 until results.length()) {
            val candidate = results.getJSONObject(i)
            val titleWords = candidate.optString("title").lowercase().split(Regex("[^a-z0-9]+")).toSet()
            if (queryWords.intersect(titleWords).isNotEmpty()) { chosen = candidate; break }
        }

        val title = chosen.optString("title")
        val titleEncoded = URLEncoder.encode(title.replace(' ', '_'), StandardCharsets.UTF_8.name())
        val summaryUrl = URL("https://en.wikipedia.org/api/rest_v1/page/summary/$titleEncoded")
        val summaryJson = JSONObject(readUrl(summaryUrl))
        val extract = summaryJson.optString("extract", "").trim()
        val pageUrl = summaryJson.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page")
            ?: "https://en.wikipedia.org/wiki/$titleEncoded"
        if (extract.isBlank()) throw IllegalStateException("A matching page was found, but it did not provide a readable summary.")

        val result = ResearchResult(title, extract, pageUrl)
        val saved = JSONObject().put("title", title).put("summary", extract).put("url", pageUrl).toString()
        preferences.edit().putString(cacheKey, saved).apply()
        return result
    }

    private fun readUrl(url: URL): String {
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9000
            readTimeout = 9000
            setRequestProperty("User-Agent", "PhysicsAI-Android/0.2 (educational project)")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Online search failed (HTTP $code). Check your connection and try again.")
            return body
        } finally {
            connection.disconnect()
        }
    }
}
