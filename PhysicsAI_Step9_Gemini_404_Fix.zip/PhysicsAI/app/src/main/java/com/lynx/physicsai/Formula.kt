package com.lynx.physicsai

data class Formula(
    val name: String,
    val equation: String,
    val definition: String,
    val symbols: String,
    val units: String,
    val conditions: String,
    val keywords: List<String>,
    val status: String = "Established physics"
)

object PhysicsKnowledge {
    val formulas = listOf(
        Formula("Speed", "v = d / t", "Distance travelled per unit of time.", "v = speed, d = distance, t = time", "m/s, m, s", "Average speed is total distance divided by total time.", listOf("speed", "distance", "time", "how fast")),
        Formula("Velocity", "v = displacement / time", "Rate of change of displacement; it includes direction.", "v = velocity", "m/s", "Average velocity uses displacement, not total path length.", listOf("velocity", "displacement", "direction")),
        Formula("Acceleration", "a = (v - u) / t", "Change in velocity per unit time.", "a = acceleration, v = final velocity, u = initial velocity, t = time", "m/s²", "This form assumes constant acceleration.", listOf("acceleration", "initial velocity", "final velocity")),
        Formula("Newton's second law", "F = m × a", "Net force equals mass multiplied by acceleration.", "F = force, m = mass, a = acceleration", "N, kg, m/s²", "Use net force in an inertial reference frame.", listOf("newton", "force", "mass", "acceleration")),
        Formula("Momentum", "p = m × v", "Linear momentum is mass multiplied by velocity.", "p = momentum, m = mass, v = velocity", "kg·m/s", "Relativistic momentum requires a different expression near light speed.", listOf("momentum", "collision", "impulse")),
        Formula("Impulse", "J = F × Δt", "Impulse equals the change in momentum; for constant force it is force times time interval.", "J = impulse, F = net force, Δt = time interval", "N·s", "For changing force, use the time integral of force.", listOf("impulse", "change in momentum")),
        Formula("Kinetic energy", "Eₖ = ½mv²", "Energy associated with motion in classical mechanics.", "m = mass, v = speed", "J", "Classical formula works well when speed is much less than light speed.", listOf("kinetic energy", "moving", "energy")),
        Formula("Work", "W = Fd cos θ", "Energy transferred by a force through a displacement.", "F = force, d = displacement, θ = angle between force and displacement", "J", "For variable forces, calculate the integral along the path.", listOf("work done", "work", "displacement")),
        Formula("Power", "P = E / t", "Rate of energy transfer or work done.", "P = power, E = energy, t = time", "W", "Use the energy transferred during the matching time interval.", listOf("power", "energy rate")),
        Formula("Gravitational potential energy", "ΔEₚ ≈ mgh", "Near Earth's surface, the change in gravitational potential energy is approximately mass times gravitational field strength times height change.", "m = mass, g = field strength, h = height change", "J", "Assumes g is approximately constant.", listOf("potential energy", "height", "gravity")),
        Formula("Weight", "W = mg", "Gravitational force on an object near a planet's surface.", "m = mass, g = gravitational field strength", "N", "The value of g varies with location and altitude.", listOf("weight", "gravity", "gravitational")),
        Formula("Density", "ρ = m / V", "Mass per unit volume.", "ρ = density, m = mass, V = volume", "kg/m³", "Use compatible mass and volume units.", listOf("density", "mass", "volume")),
        Formula("Pressure", "p = F / A", "Normal force per unit area.", "F = perpendicular force, A = area", "Pa", "For fluids at rest, pressure also varies with depth.", listOf("pressure", "area")),
        Formula("Hooke's law", "F = -kx", "For an ideal spring, restoring force is proportional to displacement from equilibrium.", "k = spring constant, x = displacement", "N/m for k", "Valid within the spring's elastic range.", listOf("hooke", "spring", "elastic")),
        Formula("Circular motion", "a = v² / r", "Centripetal acceleration points toward the centre of a circular path.", "v = speed, r = radius", "m/s²", "Applies to instantaneous circular motion.", listOf("circular motion", "centripetal", "orbit")),
        Formula("Gravitation", "F = Gm₁m₂ / r²", "Newtonian gravitational attraction between two point masses or spherical bodies outside each other.", "G = gravitational constant, m₁ and m₂ = masses, r = separation", "N", "General relativity is needed for strong gravity or high precision in some settings.", listOf("gravitation", "gravity force", "newton gravity", "orbit")),
        Formula("Orbital speed (circular)", "v = √(GM/r)", "Speed for an ideal circular orbit around a central mass.", "G = gravitational constant, M = central mass, r = orbital radius", "m/s", "Assumes a much smaller orbiting body and a circular orbit.", listOf("orbital speed", "satellite", "circular orbit")),
        Formula("First law of thermodynamics", "ΔU = Q - W", "Change in a system's internal energy equals heat added to it minus work done by the system, under this sign convention.", "ΔU = internal energy change, Q = heat added, W = work done by system", "J", "Sign conventions differ by textbook; state which convention is used.", listOf("first law", "thermodynamics", "internal energy", "heat")),
        Formula("Ideal gas law", "pV = nRT", "Relates pressure, volume, amount of gas, and absolute temperature for an ideal gas.", "p = pressure, V = volume, n = moles, R = gas constant, T = kelvin temperature", "SI units", "Approximation works best at relatively low density and away from condensation.", listOf("ideal gas", "gas law", "pressure volume temperature")),
        Formula("Heat transfer", "Q = mcΔT", "Heat associated with a temperature change when specific heat capacity is approximately constant.", "m = mass, c = specific heat capacity, ΔT = temperature change", "J", "Does not include latent heat during a phase change.", listOf("specific heat", "heat capacity", "temperature change")),
        Formula("Wave speed", "v = fλ", "Wave speed equals frequency times wavelength.", "f = frequency, λ = wavelength", "m/s", "Frequency and wavelength must describe the same wave in the same medium.", listOf("wave", "frequency", "wavelength")),
        Formula("Simple harmonic motion", "a = -ω²x", "In ideal simple harmonic motion, acceleration is proportional to displacement and directed toward equilibrium.", "ω = angular frequency, x = displacement", "m/s²", "Applies to ideal SHM, such as small-angle pendulum motion.", listOf("simple harmonic", "oscillation", "angular frequency")),
        Formula("Snell's law", "n₁ sin θ₁ = n₂ sin θ₂", "Describes refraction at a boundary between two optical media.", "n = refractive index, θ = angle measured from the normal", "dimensionless indices", "Angles are measured from the normal; total internal reflection can occur.", listOf("snell", "refraction", "refractive index")),
        Formula("Photon energy", "E = hf", "Energy of a photon is Planck's constant multiplied by its frequency.", "h = Planck constant, f = frequency", "J", "A core quantum relation for electromagnetic radiation.", listOf("photon", "planck", "quantum energy", "frequency of light")),
        Formula("Mass-energy equivalence", "E₀ = mc²", "Rest energy corresponds to mass multiplied by the square of the speed of light.", "m = rest mass, c = speed of light", "J", "This is rest energy; total relativistic energy depends on momentum too.", listOf("relativity", "einstein", "mass energy", "e=mc2")),
        Formula("Time dilation", "Δt = γΔτ", "In special relativity, observers in relative inertial motion can measure different elapsed times.", "γ = 1/√(1-v²/c²), Δτ = proper time", "s", "Special-relativistic form for inertial relative motion; gravity also affects clocks.", listOf("time dilation", "special relativity", "relativity clock")),
        Formula("Lorentz factor", "γ = 1 / √(1 - v²/c²)", "Factor used in special relativity to describe relativistic effects.", "v = relative speed, c = speed of light", "dimensionless", "For physical massive objects, v is below c.", listOf("lorentz factor", "gamma", "relativistic")),
        Formula("Ohm's law", "V = IR", "For an ohmic component under constant physical conditions, voltage equals current times resistance.", "V = voltage, I = current, R = resistance", "V, A, Ω", "Not every component obeys Ohm's law in every condition.", listOf("ohm", "voltage", "current", "resistance", "electricity")),
        Formula("Electric power", "P = VI", "Electrical power equals voltage multiplied by current.", "P = power, V = voltage, I = current", "W", "For AC circuits, real power generally requires power factor.", listOf("electric power", "power circuit", "voltage current")),
        Formula("Coulomb's law", "F = k|q₁q₂| / r²", "Magnitude of electrostatic force between two point charges in vacuum.", "k = Coulomb constant, q = charge, r = separation", "N", "Direction depends on charge signs; material media alter the relation.", listOf("coulomb", "electric force", "charge")),
        Formula("Capacitance", "C = Q / V", "Capacitance is charge stored per potential difference for a capacitor.", "C = capacitance, Q = charge, V = voltage", "F", "For a linear capacitor; capacitance depends on geometry and dielectric.", listOf("capacitance", "capacitor", "charge stored")),
        Formula("Magnetic force on a charge", "F = qvB sin θ", "Magnetic force magnitude on a moving charge in a magnetic field.", "q = charge, v = speed, B = magnetic field, θ = angle", "N", "This is the magnetic part of the Lorentz force; electric fields add qE.", listOf("magnetic force", "lorentz force", "magnetic field")),
        Formula("Radioactive decay", "N = N₀e^(-λt)", "Ideal exponential model for the number of undecayed nuclei in a sample.", "N₀ = initial number, λ = decay constant, t = time", "N is a count", "Describes statistical decay of a large population of independent nuclei.", listOf("radioactive decay", "half life", "nuclear decay")),
        Formula("Half-life", "t½ = ln(2) / λ", "Time required for half the radioactive nuclei in a sample to decay on average.", "λ = decay constant", "s or other time unit", "The decay constant is characteristic of the radionuclide.", listOf("half-life", "half life", "decay constant")),
        Formula("De Broglie wavelength", "λ = h / p", "A particle with momentum p has an associated matter-wave wavelength.", "h = Planck constant, p = momentum", "m", "Use relativistic momentum at relativistic speeds.", listOf("de broglie", "matter wave", "quantum wavelength")),
        Formula("Heisenberg uncertainty principle", "Δx Δp ≥ ℏ/2", "Quantum position and momentum spreads cannot both be made arbitrarily small for the same state.", "Δx = position spread, Δp = momentum spread, ℏ = reduced Planck constant", "m·kg·m/s", "This is a state uncertainty relation, not merely a measurement-tool limitation.", listOf("uncertainty principle", "heisenberg", "quantum uncertainty")),
        Formula("Schwarzschild radius", "rₛ = 2GM / c²", "Characteristic radius associated with a non-rotating, uncharged black hole's event horizon.", "G = gravitational constant, M = mass, c = speed of light", "m", "Exact for the ideal Schwarzschild solution in general relativity.", listOf("schwarzschild", "black hole radius", "event horizon")),
        Formula("Hubble-Lemaître relation", "v ≈ H₀d", "At relatively small cosmological distances, recession velocity is approximately proportional to distance.", "H₀ = present Hubble parameter, d = distance", "km/s/Mpc commonly", "A simplified relation; cosmological expansion is more complex over large redshifts.", listOf("hubble", "expanding universe", "cosmology", "recession velocity")),
        Formula("Thermal radiation (Stefan–Boltzmann)", "P = σAT⁴", "Ideal blackbody radiated power is proportional to surface area and absolute temperature to the fourth power.", "σ = Stefan–Boltzmann constant, A = area, T = kelvin temperature", "W", "For a real surface, emissivity and surroundings must be considered.", listOf("stefan boltzmann", "blackbody", "thermal radiation")),
        Formula("Fluid continuity (incompressible)", "A₁v₁ = A₂v₂", "For steady incompressible flow in a streamtube, flow rate is conserved.", "A = cross-sectional area, v = average flow speed", "m³/s flow rate", "Assumes steady flow and incompressible fluid.", listOf("continuity equation", "fluid flow", "incompressible")),
        Formula("Reynolds number", "Re = ρvL / μ", "Dimensionless indicator comparing inertial and viscous effects in fluid flow.", "ρ = density, v = characteristic speed, L = length scale, μ = dynamic viscosity", "dimensionless", "Transition thresholds depend on geometry and flow conditions.", listOf("reynolds number", "turbulence", "fluid dynamics")),
        Formula("Diffraction limit (Rayleigh criterion)", "θ ≈ 1.22 λ / D", "Approximate angular resolution of a circular aperture under the Rayleigh criterion.", "λ = wavelength, D = aperture diameter", "radians", "Idealized circular aperture; real instruments also have other limits.", listOf("rayleigh criterion", "diffraction limit", "telescope resolution"))
    )

    val advancedTopics = listOf(
        "Quantum mechanics — describes matter and radiation at small scales using states, amplitudes, operators, and probabilities. Interpretations of quantum mechanics remain debated, while its experimental predictions are extremely well tested.",
        "Quantum field theory — combines quantum principles with special relativity and treats fields as fundamental; it underpins the Standard Model of particle physics.",
        "General relativity — describes gravity as spacetime curvature and has strong evidence from light bending, gravitational waves, black holes, and precision timing.",
        "Particle physics — studies elementary particles and their interactions. The Standard Model is highly successful but does not include a complete quantum theory of gravity or explain all dark matter evidence.",
        "Cosmology — studies the universe's origin, evolution, large-scale structure, and expansion. Dark matter and dark energy are supported by observations, but their underlying nature remains unknown.",
        "Astrophysics — applies physics to stars, planets, galaxies, compact objects, cosmic rays, and high-energy events.",
        "Plasma physics — studies ionized gases and collective electromagnetic behavior, relevant to stars, fusion devices, space weather, and industrial plasmas.",
        "Condensed-matter physics — investigates materials and collective behavior, including semiconductors, superconductivity, magnetism, and quantum materials.",
        "Superconductivity — some materials conduct electricity with zero DC resistance below characteristic conditions; the mechanisms and practical limits differ by material, and high-temperature superconductivity remains an active research area.",
        "Fusion energy — aims to release energy by joining light nuclei. Magnetic and inertial confinement have achieved important milestones, but practical, economical, continuous grid power remains an engineering and scientific challenge.",
        "Nanophysics — studies phenomena at nanometre scales where quantum effects, surfaces, and size-dependent properties can dominate.",
        "Geophysics — applies physics to Earth's interior, seismic waves, gravity, magnetism, oceans, and atmosphere.",
        "Biophysics — applies physical principles to living systems, including molecular motion, membranes, biomechanics, and neural signals.",
        "Acoustics — studies sound, vibration, wave propagation, noise, and room or underwater acoustics.",
        "Nonlinear dynamics and chaos — studies systems where small changes can produce large differences; chaotic behavior can be deterministic yet difficult to predict long term.",
        "Statistical mechanics — connects microscopic states to macroscopic properties such as temperature, entropy, and pressure.",
        "Information physics — explores physical limits of information storage, computation, measurement, and thermodynamics; specific claims must be judged by their evidence and assumptions.",
        "Quantum computing — uses quantum states to perform certain computational tasks differently from classical computers; it does not make every problem faster and current devices face noise and scaling challenges.",
        "Gravitational waves — ripples in spacetime produced by accelerating mass distributions; they have been directly detected from compact-object mergers.",
        "Dark matter — an inferred source of gravitational effects in galaxies and cosmic structure; its particle identity or alternative explanation remains unresolved.",
        "Dark energy — a name for the cause of the observed accelerated expansion in standard cosmology; its physical nature is unknown.",
        "Black holes — regions described by general relativity where an event horizon prevents signals from escaping outward; detailed quantum behavior of black holes remains an active research area.",
        "Emergent phenomena — large-scale properties such as superconductivity, fluid behavior, and magnetism that arise from interactions among many components.",
        "Metamaterials — engineered structures whose designed internal geometry produces unusual effective electromagnetic or acoustic properties.",
        "Computational physics — uses numerical methods and simulation to study systems that are difficult to solve analytically; results depend on model assumptions, resolution, and validation.",
        "Experimental uncertainty — measurements have uncertainty from instrument limits, calibration, random variation, and model assumptions; uncertainty should be reported rather than hidden.",
        "Scientific method in physics — models make quantitative predictions that are compared with reproducible observations and experiments; a model can be useful without being a final description of nature.",
        "Open questions — quantum gravity, the matter–antimatter asymmetry, dark matter's nature, dark energy's nature, and the origin of some cosmic features remain unresolved. Competing hypotheses are not established facts.",
        "Beyond-standard-model physics — proposed extensions to established theories, such as new particles or symmetries; these proposals require experimental evidence before being treated as discoveries.",
        "Astrobiology and planetary physics — combines physics, chemistry, geology, and biology to study planetary environments and conditions that could support life; possible extraterrestrial life has not been confirmed."
    )

    fun search(question: String): Formula? {
        val q = question.lowercase()
        return formulas
            .map { formula ->
                val searchable = listOf(formula.name) + formula.keywords
                formula to searchable.count { q.contains(it.lowercase()) }
            }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
            ?.first
    }

    fun searchAdvancedTopic(question: String): String? {
        val q = question.lowercase()
        return advancedTopics
            .map { it to topicScore(it, q) }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
            ?.first
    }

    private fun topicScore(topic: String, q: String): Int {
        val title = topic.substringBefore(" — ").lowercase()
        val words = title.split(Regex("[^a-z0-9]+")).filter { it.length > 2 }
        return words.count { q.contains(it) }
    }
}
