package com.lynx.physicsai

import java.util.Locale

class PhysicsEngine {

    fun answer(question: String): String {
        val q = question.trim()
        if (q.isBlank()) return "Type a physics question first."

        val lower = q.lowercase(Locale.ROOT)
        val matched = PhysicsKnowledge.search(q)

        val numericAnswer = when {
            ("speed" in lower || "velocity" in lower) &&
                ("calculate" in lower || "solve" in lower || "find" in lower) -> solveSpeed(q)
            "density" in lower &&
                ("calculate" in lower || "solve" in lower || "find" in lower) -> solveDensity(q)
            else -> null
        }

        if (numericAnswer != null) return numericAnswer

        if (matched != null) {
            return buildString {
                appendLine("TOPIC: ${matched.name}")
                appendLine("DEFINITION: ${matched.definition}")
                appendLine("FORMULA: ${matched.equation}")
                appendLine("SYMBOLS: ${matched.symbols}")
                appendLine("UNITS: ${matched.units}")
                appendLine("VALIDITY / LIMITS: ${matched.conditions}")
                append("STATUS: ${matched.status}")
            }
        }

        val advanced = PhysicsKnowledge.searchAdvancedTopic(q)
        if (advanced != null) {
            return "ADVANCED PHYSICS KNOWLEDGE\n\n$advanced\n\nEvidence note: this summary separates well-tested theory from open research questions where relevant. Ask a narrower follow-up for more detail."
        }

        return "I couldn't confidently match that question to my built-in knowledge. Try asking about mechanics, thermodynamics, waves, optics, electricity, magnetism, relativity, quantum physics, particle physics, cosmology, astrophysics, plasma, materials, fluids, geophysics, or biophysics.\n\nThis is a local knowledge-based starter app, not a complete AI model. It can explain its stored topics and currently solves numerical speed and density questions only."
    }

    private fun solveSpeed(question: String): String? {
        val distance = findValue(question, listOf("distance", "d"))
        val time = findValue(question, listOf("time", "t"))
        if (distance == null || time == null || time == 0.0) return null

        val speed = UnitCalculator.divide(distance, time)
        return "SOLUTION: Speed\n\nFormula: v = d / t\nSubstitute: v = ${UnitCalculator.format(distance)} / ${UnitCalculator.format(time)}\nAnswer: v = ${UnitCalculator.format(speed)} distance-units per time-unit\n\nDefinition: Speed is distance travelled per unit time.\nCheck: Ensure distance and time use compatible units. For example, metres and seconds give m/s."
    }

    private fun solveDensity(question: String): String? {
        val mass = findValue(question, listOf("mass", "m"))
        val volume = findValue(question, listOf("volume", "v"))
        if (mass == null || volume == null || volume == 0.0) return null

        val density = UnitCalculator.divide(mass, volume)
        return "SOLUTION: Density\n\nFormula: ρ = m / V\nSubstitute: ρ = ${UnitCalculator.format(mass)} / ${UnitCalculator.format(volume)}\nAnswer: ρ = ${UnitCalculator.format(density)} mass-units per volume-unit\n\nDefinition: Density is mass per unit volume.\nCheck: Use compatible units, such as kg and m³ to get kg/m³."
    }

    private fun findValue(text: String, labels: List<String>): Double? {
        for (label in labels.sortedByDescending { it.length }) {
            val regex = Regex("""(?i)\b${Regex.escape(label)}\b\s*(?:is|of|=|:)?\s*(-?\d+(?:\.\d+)?)""")
            val match = regex.find(text)
            if (match != null) return match.groupValues[1].toDoubleOrNull()
        }
        return null
    }
}
