package com.lynx.physicsai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * User-controlled local research library.
 * Entries are stored privately on-device. "Reviewed" records a user action;
 * it does not mean that a claim has been scientifically proven.
 */
class SavedKnowledgeStore(context: Context) {
    data class Entry(
        val id: String,
        val question: String,
        val title: String,
        val summary: String,
        val sourceUrl: String,
        val savedAt: Long,
        val reviewed: Boolean
    ) {
        fun formattedDate(): String =
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(savedAt))
    }

    private val file = File(context.applicationContext.filesDir, "physicsai_saved_knowledge.json")

    @Synchronized
    fun all(): List<Entry> {
        return try {
            if (!file.exists()) return emptyList()
            val array = JSONArray(file.readText(Charsets.UTF_8))
            (0 until array.length()).mapNotNull { index ->
                val obj = array.optJSONObject(index) ?: return@mapNotNull null
                Entry(
                    id = obj.optString("id"),
                    question = obj.optString("question"),
                    title = obj.optString("title"),
                    summary = obj.optString("summary"),
                    sourceUrl = obj.optString("sourceUrl"),
                    savedAt = obj.optLong("savedAt"),
                    reviewed = obj.optBoolean("reviewed", false)
                )
            }.sortedByDescending { it.savedAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun save(question: String, title: String, summary: String, sourceUrl: String): Entry {
        val q = question.trim().take(500)
        val t = title.trim().take(300)
        val s = summary.trim().take(12000)
        val url = sourceUrl.trim().take(2000)
        require(q.isNotBlank()) { "Question cannot be empty." }
        require(t.isNotBlank()) { "Source title cannot be empty." }
        require(s.isNotBlank()) { "Source summary cannot be empty." }
        require(url.startsWith("https://")) { "Only HTTPS source links can be saved." }

        val entry = Entry(
            id = "${System.currentTimeMillis()}_${t.hashCode()}",
            question = q,
            title = t,
            summary = s,
            sourceUrl = url,
            savedAt = System.currentTimeMillis(),
            reviewed = false
        )
        val updated = all()
            .filterNot { it.sourceUrl == url && it.question.equals(q, ignoreCase = true) }
            .toMutableList()
        updated.add(0, entry)
        write(updated.take(MAX_ENTRIES))
        return entry
    }

    @Synchronized
    fun markReviewed(id: String): Boolean {
        var found = false
        val updated = all().map { entry ->
            if (entry.id == id) {
                found = true
                entry.copy(reviewed = true)
            } else entry
        }
        if (found) write(updated)
        return found
    }

    @Synchronized
    fun delete(id: String): Boolean {
        val old = all()
        val updated = old.filterNot { it.id == id }
        if (updated.size == old.size) return false
        write(updated)
        return true
    }

    @Synchronized
    fun clear(): Int {
        val count = all().size
        if (file.exists()) file.delete()
        return count
    }

    private fun write(entries: List<Entry>) {
        val array = JSONArray()
        entries.forEach { entry ->
            array.put(JSONObject().apply {
                put("id", entry.id)
                put("question", entry.question)
                put("title", entry.title)
                put("summary", entry.summary)
                put("sourceUrl", entry.sourceUrl)
                put("savedAt", entry.savedAt)
                put("reviewed", entry.reviewed)
            })
        }
        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(array.toString(2), Charsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(array.toString(2), Charsets.UTF_8)
            temp.delete()
        }
    }

    companion object {
        private const val MAX_ENTRIES = 500
    }
}
