Wrapper distribution is pinned to Gradle 8.11.1 in gradle-wrapper.properties.
The wrapper JAR is not bundled in this starter ZIP. Android Studio/CodeAssist can sync the project and create/manage wrapper files, or run 'gradle wrapper --gradle-version 8.11.1' from a machine with Gradle installed.
