# PhysicsAI — Step 8: API Diagnostics and Reliability Fixes

Android project using Kotlin, Java, XML, and Gradle.

## What changed to debug "no answer / API error"
- Added a **Test AI API connection** button on the main screen. It sends a small request using the currently saved provider, model ID, and key.
- Improved API error diagnostics. HTTP 400, 401, 403, 404, 408, 429, and 5xx errors now show a likely cause and the provider's error message when available.
- Added validation for empty model IDs, missing keys, and non-HTTPS endpoints.
- Improved handling of non-JSON responses, missing `choices`, and compatible APIs returning text in different content shapes.
- Keeps AI requests off the main UI thread and returns errors visibly in the answer area.

## Recommended debugging steps
1. Open **AI Provider Settings**.
2. Choose one provider, then copy an exact model ID that is currently available in that provider account. Preset IDs are examples and can become unavailable.
3. Enter that provider's own API key. Do not use an OpenAI key with another provider or vice versa.
4. Save the settings.
5. Tap **Test AI API connection**.
6. Read the diagnostic text shown in the answer area. If it fails, share the exact HTTP status and provider detail (remove any API key or other secrets first).
7. If the test passes, try a simple question such as: `A car travels 120 metres in 10 seconds. Calculate its average speed and explain each step.`

## Common errors
- **HTTP 400** — model ID, request parameter, or API format may be unsupported.
- **HTTP 401** — wrong, expired, or mismatched API key.
- **HTTP 403** — account/model permission problem.
- **HTTP 404** — wrong API base URL or unavailable model.
- **HTTP 429** — quota, billing, or rate limit.
- **No `choices` field** — endpoint may not be a Chat Completions-compatible API.
- **Timeout / connection error** — check internet, provider service status, and retry.

## Compatibility notes
The client expects an OpenAI-compatible `/chat/completions` endpoint. Provider presets and model names are starting points, not guarantees of current availability. A provider's native API may need a dedicated adapter. The app cannot automatically support every API format simply by changing its URL.

## Security and cost
API requests can cost money. This personal-testing prototype stores the API key in app-private preferences, but that is not sufficient for a public production app. Never share your key or include it in a public APK. For release, move provider calls to a secured backend with authentication and usage limits.

## Build requirements and status
JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.10.1, Kotlin Android plugin 2.1.20, Gradle 8.11.1. Open the `PhysicsAI` folder in CodeAssist or Android Studio and sync Gradle. The Gradle wrapper JAR is not included. XML and ZIP integrity are checked, but a full Gradle build has not been run in this environment.


## Step 9: Gemini HTTP 404 fix (October 2026)

The previous Gemini preset used `gemini-2.5-flash`, which may return HTTP 404 for accounts/projects without access to the older 2.5 model. The preset now uses the currently listed stable model ID `gemini-3.8-flash`.

Gemini OpenAI-compatible settings:
- Base URL: `https://generativelanguage.googleapis.com/v1beta/openai`
- Model ID: `gemini-3.8-flash`
- Endpoint constructed by this app: `https://generativelanguage.googleapis.com/v1beta/openai/chat/completions`

After importing/updating this project, open AI Provider Settings, select Google Gemini, paste your own Gemini API key, save, and tap Test AI API connection. Do not share your API key.

If HTTP 404 remains, open the Google AI Studio project tied to that key and confirm `gemini-3.8-flash` is listed and available for that key. Copy the exact model ID shown there. If the provider error says the URL is invalid, confirm the final URL ends with `/v1beta/openai/chat/completions` exactly once. The app automatically appends `/chat/completions`, so do not enter that suffix in the Base URL.

This archive has had its source preset updated and ZIP/XML integrity checked. A full Android Gradle build has not been run in this environment.
