@echo off
if exist "%~dp0gradle\wrapper\gradle-wrapper.jar" (
  java -classpath "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
) else (
  echo Gradle wrapper JAR is not included. Open this folder in Android Studio/CodeAssist and sync Gradle, or install Gradle 8.11.1 and run: gradle assembleDebug
  exit /b 1
)
